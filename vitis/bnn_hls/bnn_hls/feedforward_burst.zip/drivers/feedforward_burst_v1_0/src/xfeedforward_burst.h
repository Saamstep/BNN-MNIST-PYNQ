// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XFEEDFORWARD_BURST_H
#define XFEEDFORWARD_BURST_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xfeedforward_burst_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XFeedforward_burst_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XFeedforward_burst;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XFeedforward_burst_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XFeedforward_burst_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XFeedforward_burst_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XFeedforward_burst_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XFeedforward_burst_Initialize(XFeedforward_burst *InstancePtr, UINTPTR BaseAddress);
XFeedforward_burst_Config* XFeedforward_burst_LookupConfig(UINTPTR BaseAddress);
#else
int XFeedforward_burst_Initialize(XFeedforward_burst *InstancePtr, u16 DeviceId);
XFeedforward_burst_Config* XFeedforward_burst_LookupConfig(u16 DeviceId);
#endif
int XFeedforward_burst_CfgInitialize(XFeedforward_burst *InstancePtr, XFeedforward_burst_Config *ConfigPtr);
#else
int XFeedforward_burst_Initialize(XFeedforward_burst *InstancePtr, const char* InstanceName);
int XFeedforward_burst_Release(XFeedforward_burst *InstancePtr);
#endif

void XFeedforward_burst_Start(XFeedforward_burst *InstancePtr);
u32 XFeedforward_burst_IsDone(XFeedforward_burst *InstancePtr);
u32 XFeedforward_burst_IsIdle(XFeedforward_burst *InstancePtr);
u32 XFeedforward_burst_IsReady(XFeedforward_burst *InstancePtr);
void XFeedforward_burst_EnableAutoRestart(XFeedforward_burst *InstancePtr);
void XFeedforward_burst_DisableAutoRestart(XFeedforward_burst *InstancePtr);

void XFeedforward_burst_Set_input_r(XFeedforward_burst *InstancePtr, u64 Data);
u64 XFeedforward_burst_Get_input_r(XFeedforward_burst *InstancePtr);
void XFeedforward_burst_Set_output_r(XFeedforward_burst *InstancePtr, u64 Data);
u64 XFeedforward_burst_Get_output_r(XFeedforward_burst *InstancePtr);

void XFeedforward_burst_InterruptGlobalEnable(XFeedforward_burst *InstancePtr);
void XFeedforward_burst_InterruptGlobalDisable(XFeedforward_burst *InstancePtr);
void XFeedforward_burst_InterruptEnable(XFeedforward_burst *InstancePtr, u32 Mask);
void XFeedforward_burst_InterruptDisable(XFeedforward_burst *InstancePtr, u32 Mask);
void XFeedforward_burst_InterruptClear(XFeedforward_burst *InstancePtr, u32 Mask);
u32 XFeedforward_burst_InterruptGetEnabled(XFeedforward_burst *InstancePtr);
u32 XFeedforward_burst_InterruptGetStatus(XFeedforward_burst *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
