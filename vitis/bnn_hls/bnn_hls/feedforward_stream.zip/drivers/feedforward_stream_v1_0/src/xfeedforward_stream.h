// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XFEEDFORWARD_STREAM_H
#define XFEEDFORWARD_STREAM_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xfeedforward_stream_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XFeedforward_stream_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XFeedforward_stream;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XFeedforward_stream_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XFeedforward_stream_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XFeedforward_stream_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XFeedforward_stream_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XFeedforward_stream_Initialize(XFeedforward_stream *InstancePtr, UINTPTR BaseAddress);
XFeedforward_stream_Config* XFeedforward_stream_LookupConfig(UINTPTR BaseAddress);
#else
int XFeedforward_stream_Initialize(XFeedforward_stream *InstancePtr, u16 DeviceId);
XFeedforward_stream_Config* XFeedforward_stream_LookupConfig(u16 DeviceId);
#endif
int XFeedforward_stream_CfgInitialize(XFeedforward_stream *InstancePtr, XFeedforward_stream_Config *ConfigPtr);
#else
int XFeedforward_stream_Initialize(XFeedforward_stream *InstancePtr, const char* InstanceName);
int XFeedforward_stream_Release(XFeedforward_stream *InstancePtr);
#endif

void XFeedforward_stream_Start(XFeedforward_stream *InstancePtr);
u32 XFeedforward_stream_IsDone(XFeedforward_stream *InstancePtr);
u32 XFeedforward_stream_IsIdle(XFeedforward_stream *InstancePtr);
u32 XFeedforward_stream_IsReady(XFeedforward_stream *InstancePtr);
void XFeedforward_stream_EnableAutoRestart(XFeedforward_stream *InstancePtr);
void XFeedforward_stream_DisableAutoRestart(XFeedforward_stream *InstancePtr);


void XFeedforward_stream_InterruptGlobalEnable(XFeedforward_stream *InstancePtr);
void XFeedforward_stream_InterruptGlobalDisable(XFeedforward_stream *InstancePtr);
void XFeedforward_stream_InterruptEnable(XFeedforward_stream *InstancePtr, u32 Mask);
void XFeedforward_stream_InterruptDisable(XFeedforward_stream *InstancePtr, u32 Mask);
void XFeedforward_stream_InterruptClear(XFeedforward_stream *InstancePtr, u32 Mask);
u32 XFeedforward_stream_InterruptGetEnabled(XFeedforward_stream *InstancePtr);
u32 XFeedforward_stream_InterruptGetStatus(XFeedforward_stream *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
